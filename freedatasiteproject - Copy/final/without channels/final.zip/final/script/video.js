  var sdvid;
  var imgid;

  var viddiv =document.getElementById("div");
  var btndiv =document.getElementById("qbtn");
  var maindiv =document.getElementById("main");



function loadVideo() {


      var x;
      var token;
  x = Math.floor((Math.random() * 7) + 1);

  if (x == 1) {
    token = "EAADZCZBGcXgFwBAJCTYSIs51ryHG9FN4UWf7Sb3ln0WcHdyekNE6bHIrbFcEqZCNwuS8Hxw21wHVijKI2evFMHcbehyRRDDwhFxZCWqvUypzRYQTMbzOhgKfwP8HcDYlUynZCUlYlsCx8ZA10mYJmdGXCSwxB6CGN9dIZB2LBrBYQZDZD"

  }
  else if(x == 2){

    token = "EAAGPhfQyfnUBALaSUCH7pOgDt7Jg9OPArf1reTWZCWNxlrPnD2IQ08RFZAgfXUliy9I0hZCWCiZCKtnqOrly8ntZBDSOtAhgogB3jy0dc7BAsOXZC7j6XpMgLe9RLpdTfQpUj3VwpJwQDh9rLury4nUzVqZBtZACR14wQXTI7StesgZDZD"

  }
  else if(x == 3){

    token = "EAAHkwE1uJCUBAKW0fsazSq1osblRoz6hOZAj4Wcxs7mjl55ZBUBicHgsXywXt8OHZBgWtb0eznfL1RqSZCElFHD8S7wOgaZC5hDURbhGQ2uyZAkWiLDrbhEp2al5YU2mQfXegI18ElrW7C5r7Jd9sOa3T2Uyr780kEaxPaFeh32gZDZD"
  }
  else if(x == 4){

    token = "EAAClYyTA9R8BALI7RPDqFcuVleQYryfe9P6svLv31vVa0CpgufNgd4uOv5rLX5JQZBjOxhBMzwhGj0a9CZAtWtm4RFuhkvvTuNHp2J3ZBSMqBT7HMxULFv3nNGuBX6JlAwsc3gw0zp48DRmA3voTI9DxDZAWMWzeuEZB6vVf7ZBgZDZD"
    }
  else if(x == 5){

    token = "EAACHZC7dk50IBADN4CeTRYMR9mEvdwQej1Cxc6AEZCeC5ZCRSxFHfCZA6GoKGiAeGCJ2c8nVL0aLPaQ1ZAjw6hZB2y3Vdr1Sn4UebRf2eSznKaAxfnoZAqcqdThYZCMwZCCejhJ05xiEeDhBZArb7dgP3NiCFXv56TRwZCGvQOw894KkwZDZD"
   }
   else if(x == 6){

   	token = "EAADaxqlrIrIBAA87OrPSogs4r3agCDzTmQdlbZAUOXSSrumpAx9gPgpwfIQukMRMqttYtvIlOApiMSo7thZADGcquAyWKHnkpb2IQts4VUjruR3V4tFiEyBQwAtJP0ReZAwfHKr9GPP2qZCUqKxi99voZC8IDFD2oezIXZAbP6KgZDZD"
   }
   else {

  	token = "EAADZCZBGcXgFwBANnkErQXRXTU0iqAAw0Q6ECqqEmIYnZAHSo51rnEQC41wOP64phqpt91dfT6iHhZAPpkxzJPR48se8fUGS6cgO8MA8yFWzKaf52TNsZAOdJpmZAHxZAOgPH7SkxPergrC6cDkSjymql3peNnlyPM605ZAfvVI7xgZDZD"
   }

    var sdid;
    
    var vidID = imgid;

        FB.api(
  '/'+vidID+'?access_token='+token+'',
  'GET',
  {
  "fields":"source,embed_html"
  
  },
  function (response,) {
                var url=response.source;
                 var embed = response.embed_html;

 sdid = embed.substring(0, embed.indexOf("%2F&"));

 sdid = sdid.substring( embed.indexOf("k%2F")+4);


                 

    

var x = document.createElement("VIDEO");

  if (x.canPlayType("video/mp4")) {
    x.setAttribute("src",url);
  } else {
    x.setAttribute("src",url);
  }

  x.setAttribute("width", "80%");
  x.setAttribute("height", "50%");
  x.setAttribute("controls", "controls");
  x.setAttribute("autoplay", "autoplay");

  var sdbtn = document.createElement("button");
  sdbtn.innerText ="SD Quality";
  sdbtn.setAttribute("id",sdid);
  sdbtn.setAttribute('onclick','SdVid(this.id);loadSdVideo()');
  sdbtn.setAttribute("class","Qbutton");


  

      viddiv.innerHTML="";
      viddiv.appendChild(x);
      btndiv.innerHTML="";
      btndiv.appendChild(sdbtn);



                });




         
    }


    function loadSdVideo() {


      var x;
      var token;
  x = Math.floor((Math.random() * 7) + 1);

  if (x == 1) {
    token = "EAADZCZBGcXgFwBAJCTYSIs51ryHG9FN4UWf7Sb3ln0WcHdyekNE6bHIrbFcEqZCNwuS8Hxw21wHVijKI2evFMHcbehyRRDDwhFxZCWqvUypzRYQTMbzOhgKfwP8HcDYlUynZCUlYlsCx8ZA10mYJmdGXCSwxB6CGN9dIZB2LBrBYQZDZD"

  }
  else if(x == 2){

    token = "EAAGPhfQyfnUBALaSUCH7pOgDt7Jg9OPArf1reTWZCWNxlrPnD2IQ08RFZAgfXUliy9I0hZCWCiZCKtnqOrly8ntZBDSOtAhgogB3jy0dc7BAsOXZC7j6XpMgLe9RLpdTfQpUj3VwpJwQDh9rLury4nUzVqZBtZACR14wQXTI7StesgZDZD"

  }
  else if(x == 3){

    token = "EAAHkwE1uJCUBAKW0fsazSq1osblRoz6hOZAj4Wcxs7mjl55ZBUBicHgsXywXt8OHZBgWtb0eznfL1RqSZCElFHD8S7wOgaZC5hDURbhGQ2uyZAkWiLDrbhEp2al5YU2mQfXegI18ElrW7C5r7Jd9sOa3T2Uyr780kEaxPaFeh32gZDZD"
  }
  else if(x == 4){

    token = "EAAClYyTA9R8BALI7RPDqFcuVleQYryfe9P6svLv31vVa0CpgufNgd4uOv5rLX5JQZBjOxhBMzwhGj0a9CZAtWtm4RFuhkvvTuNHp2J3ZBSMqBT7HMxULFv3nNGuBX6JlAwsc3gw0zp48DRmA3voTI9DxDZAWMWzeuEZB6vVf7ZBgZDZD"
    }
  else if(x == 5){

    token = "EAACHZC7dk50IBADN4CeTRYMR9mEvdwQej1Cxc6AEZCeC5ZCRSxFHfCZA6GoKGiAeGCJ2c8nVL0aLPaQ1ZAjw6hZB2y3Vdr1Sn4UebRf2eSznKaAxfnoZAqcqdThYZCMwZCCejhJ05xiEeDhBZArb7dgP3NiCFXv56TRwZCGvQOw894KkwZDZD"
   }
   else if(x == 6){

   	token = "EAADaxqlrIrIBAA87OrPSogs4r3agCDzTmQdlbZAUOXSSrumpAx9gPgpwfIQukMRMqttYtvIlOApiMSo7thZADGcquAyWKHnkpb2IQts4VUjruR3V4tFiEyBQwAtJP0ReZAwfHKr9GPP2qZCUqKxi99voZC8IDFD2oezIXZAbP6KgZDZD"
   }
   else {

  	token = "EAADZCZBGcXgFwBANnkErQXRXTU0iqAAw0Q6ECqqEmIYnZAHSo51rnEQC41wOP64phqpt91dfT6iHhZAPpkxzJPR48se8fUGS6cgO8MA8yFWzKaf52TNsZAOdJpmZAHxZAOgPH7SkxPergrC6cDkSjymql3peNnlyPM605ZAfvVI7xgZDZD"
   }
    
    var vidID = sdvid;

    console.log(sdvid);

        FB.api(
  '/'+vidID+'?access_token='+token+'',
  'GET',
  {
  "fields":"source"
  
  },
  function (response,) {
                var url=response.source;
                 


var x = document.createElement("VIDEO");

  if (x.canPlayType("video/mp4")) {
    x.setAttribute("src",url);
  } else {
    x.setAttribute("src",url);
  }

  x.setAttribute("width", "80%");
  x.setAttribute("height", "50%");
  x.setAttribute("controls", "controls");
  x.setAttribute("autoplay", "autoplay");

  var hdbtn = document.createElement("button");
  hdbtn.innerText ="HD Quality";
  hdbtn.setAttribute("id",imgid);
  hdbtn.setAttribute('onclick','VidID(this.id);loadVideo()');
  hdbtn.setAttribute("class","Qbutton");

  

      viddiv.innerHTML="";
      viddiv.appendChild(x);
      btndiv.innerHTML="";
      btndiv.appendChild(hdbtn);



                });




         
    }




    function  SdVid(clickID){

        sdvid = clickID;

    }


    function  VidID(clickID){

       imgid = clickID;

       

    }



    function AddCloseBtn(){



        var CloseBtn = document.createElement("button");
        CloseBtn.setAttribute("class","close-button");
        CloseBtn.setAttribute("id","CloseBtn");
        CloseBtn.setAttribute('onclick','CloseBtn();menuClose()');
        CloseBtn.innerText = "Close X";

        maindiv.appendChild(CloseBtn);


    }

    function checkCloseBtn(){

        var closebtn = document.getElementById("CloseBtn");

        if (closebtn != undefined) {

          closebtn.remove();

        }


    }


    function CloseBtn(){


       var clsbtn =  document.getElementById("CloseBtn");

        viddiv.innerHTML="";
        btndiv.innerHTML="";
        clsbtn.remove();


    }

