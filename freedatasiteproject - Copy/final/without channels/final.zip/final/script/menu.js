
      var menudiv = document.getElementById("menu");
          var menubtn = document.getElementById("menubtn");

          var span1 = document.getElementById("span1");
          var span2 = document.getElementById("span2");
          var span3 = document.getElementById("span3");
          var span4 = document.getElementById("span4");
          var span5 = document.getElementById("span5");

          var cat = document.querySelectorAll("[name='category']"); 
          

          
          

        function menuOpen(){

          

         var x = document.querySelectorAll(".menuspan");

         for(var i = 0;i<x.length;i++){ 
          
            x[i].classList.remove("menuspan");
            x[i].classList.add("menuspan-visible");

          }


          menubtn.removeAttribute("onclick");
          menubtn.setAttribute("onclick","menuClose()");
          menubtn.setAttribute("class","fa fa-arrow-left")
          span2.setAttribute("onclick","showCategories()");

            document.getElementById("overlay").setAttribute("class","overlay");
            document.getElementById("overlay").setAttribute("onclick","menuClose()");
          
          


        }


        function menuClose(){

      var span6 = document.getElementById("span6");
      document.getElementById("overlay").removeAttribute("class");
      document.getElementById("overlay").removeAttribute("onclick");


          var x = document.querySelectorAll(".menuspan-visible");

         for(var i = 0;i<x.length;i++){ 
          
            x[i].classList.remove("menuspan-visible");
            x[i].classList.add("menuspan");

          }

          menubtn.removeAttribute("onclick");
          menubtn.setAttribute("onclick","menuOpen()");
          menubtn.setAttribute("class","fa fa-bars")
          
          menubtn.innerText="";


         for (var i = 0; i < cat.length ; i++) {

            cat[i].setAttribute("class","catspan");

        }

        

      }


        function showCategories(){

        //  span3.setAttribute("class","menuspan");
        //  span4.setAttribute("class","menuspan");
        //  span5.setAttribute("class","menuspan");

        

          for (var i = 0; i < cat.length ; i++) {

            cat[i].setAttribute("class","cat-menu");
            cat[i].setAttribute("onclick","loadCategory(this.id);catTitle(this.innerText)");

        }
          
          
          

          

          span2.setAttribute("onclick","closeCategory()");



        }

        function catTitle(text){

          var title = document.getElementById("title");
          var titlespan = document.createElement("span");
          title.innerHTML="";

          titlespan.textContent = text;
          titlespan.setAttribute("style","font-size:20px");
          title.appendChild(titlespan);



        }

        function closeCategory(){

        //  span3.setAttribute("class","menuspan-visible");
        //  span4.setAttribute("class","menuspan-visible");
        //  span5.setAttribute("class","menuspan-visible");


          for (var i = 0; i < cat.length ; i++) {

            cat[i].setAttribute("class","catspan");

        }
          

          

          span2.setAttribute("onclick","showCategories()");

        }


        function loadCategory(catId){


          

          var div = document.getElementById("thumb");
          var next = document.getElementById('navigation');
          div.innerHTML="";
          next.innerHTML="";

          const span = document.createElement('span');
              var txt = document.createTextNode("Loading..");
              span.setAttribute("class","span");
              span.appendChild(txt);
              next.appendChild(span);

          setTimeout(function(){


        if (span.innerText == "Loading..") {

          span.innerText ="Error Loading..! Check Your Connection & Try Again..";
        }


      },20000);  


     var category = catId;

       var after = "";  


      var x;
      var token;
  x = Math.floor((Math.random() * 7) + 1);

  if (x == 1) {
    token = "EAADZCZBGcXgFwBAJCTYSIs51ryHG9FN4UWf7Sb3ln0WcHdyekNE6bHIrbFcEqZCNwuS8Hxw21wHVijKI2evFMHcbehyRRDDwhFxZCWqvUypzRYQTMbzOhgKfwP8HcDYlUynZCUlYlsCx8ZA10mYJmdGXCSwxB6CGN9dIZB2LBrBYQZDZD"

  }
  else if(x == 2){

    token = "EAAGPhfQyfnUBALaSUCH7pOgDt7Jg9OPArf1reTWZCWNxlrPnD2IQ08RFZAgfXUliy9I0hZCWCiZCKtnqOrly8ntZBDSOtAhgogB3jy0dc7BAsOXZC7j6XpMgLe9RLpdTfQpUj3VwpJwQDh9rLury4nUzVqZBtZACR14wQXTI7StesgZDZD"

  }
  else if(x == 3){

    token = "EAAHkwE1uJCUBAKW0fsazSq1osblRoz6hOZAj4Wcxs7mjl55ZBUBicHgsXywXt8OHZBgWtb0eznfL1RqSZCElFHD8S7wOgaZC5hDURbhGQ2uyZAkWiLDrbhEp2al5YU2mQfXegI18ElrW7C5r7Jd9sOa3T2Uyr780kEaxPaFeh32gZDZD"
  }
  else if(x == 4){

    token = "EAAClYyTA9R8BALI7RPDqFcuVleQYryfe9P6svLv31vVa0CpgufNgd4uOv5rLX5JQZBjOxhBMzwhGj0a9CZAtWtm4RFuhkvvTuNHp2J3ZBSMqBT7HMxULFv3nNGuBX6JlAwsc3gw0zp48DRmA3voTI9DxDZAWMWzeuEZB6vVf7ZBgZDZD"
    }
  else if(x == 5){

    token = "EAACHZC7dk50IBADN4CeTRYMR9mEvdwQej1Cxc6AEZCeC5ZCRSxFHfCZA6GoKGiAeGCJ2c8nVL0aLPaQ1ZAjw6hZB2y3Vdr1Sn4UebRf2eSznKaAxfnoZAqcqdThYZCMwZCCejhJ05xiEeDhBZArb7dgP3NiCFXv56TRwZCGvQOw894KkwZDZD"
   }
   else if(x == 6){

    token = "EAADaxqlrIrIBAA87OrPSogs4r3agCDzTmQdlbZAUOXSSrumpAx9gPgpwfIQukMRMqttYtvIlOApiMSo7thZADGcquAyWKHnkpb2IQts4VUjruR3V4tFiEyBQwAtJP0ReZAwfHKr9GPP2qZCUqKxi99voZC8IDFD2oezIXZAbP6KgZDZD"
   }
   else {

    token = "EAADZCZBGcXgFwBANnkErQXRXTU0iqAAw0Q6ECqqEmIYnZAHSo51rnEQC41wOP64phqpt91dfT6iHhZAPpkxzJPR48se8fUGS6cgO8MA8yFWzKaf52TNsZAOdJpmZAHxZAOgPH7SkxPergrC6cDkSjymql3peNnlyPM605ZAfvVI7xgZDZD"
   }

        


            FB.api(
        '/723002398151771/videos?access_token='+token+'&after='+after,
        'GET',
              {
                "fields":"picture,id,description","limit":300
              },

        

        function(response) {


          var res = response; 
          var desc;
          var cat_pos;


          for (var i = 0;  i < response.data.length; i++) {

                desc = response.data[i].description;
            var thumburl = response.data[i].picture;
            var thumbID = response.data[i].id;
                

          if (desc != undefined) {

            cat_pos = desc.indexOf(""+category+"");

           if (cat_pos > -1) {


              var img = new Image();
              
        
              
              div.appendChild(img);
              

                img.src = thumburl;
                img.setAttribute("class","image");
                img.id = thumbID;
                img.setAttribute('onclick','VidID(this.id);loadVideo();setTimeout(checkCloseBtn,1999);setTimeout(AddCloseBtn, 2000)');
            }

         
            }


       


    

       } 

       var check = response.paging.next;

              after = response.paging.cursors.after;

            

              if (check !== undefined) {

            
              
              next.innerHTML="";
              const button = document.createElement('button');
              button.innerText = "Load More..";
              next.appendChild(button);
              button.setAttribute('onclick','loadCategory()');
              button.setAttribute("type", "button");
              button.setAttribute("class","button");

            }

            else{
              next.innerHTML="";
              const span = document.createElement('span');
              var txt = document.createTextNode("No More Videos to load.. Check Back later");
              span.setAttribute("class","span2");
              span.appendChild(txt);
              next.appendChild(span); 

    

       }



        });



      }
